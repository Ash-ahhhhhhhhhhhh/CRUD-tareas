# CRUD-tareas

Pequeña aplicación web para gestionar tareas (crear, leer, actualizar, eliminar) con autenticación de usuarios y preferencias de visualización.

**Características**
- **Autenticación:** registro e inicio de sesión con sesiones basadas en cookies.
- **CRUD de tareas:** título, descripción, prioridad y fecha de vencimiento por usuario.
- **Preferencias por usuario:** tema (claro/oscuro), color de tabla y opción "arcoíris" guardadas en SQLite.
- **Protección de assets sensibles:** `script.js` no se muestra por acceso directo a su URL.

**Archivos importantes**
- [server.js](server.js#L1): servidor Express, API y control de sesiones.
- [public/index.html](public/index.html#L1): interfaz principal de la app.
- [public/login.html](public/login.html#L1): página de login/registro.
- [public/script.js](public/script.js#L1): lógica cliente (UI, peticiones a la API).
- [database/tareas.db](database/tareas.db): base de datos SQLite creada al ejecutar la app.

Requisitos
- Node.js (v16+ recomendable)
- npm

Instalación (una sola vez)

1. Clona el repositorio o descarga los archivos en una carpeta.
2. Abre una terminal en la carpeta del proyecto (`CRUD-tareas`).
3. Instala dependencias:

```bash
npm install
```

Cómo ejecutar la aplicación

1. Iniciar el servidor (por defecto usa el puerto `3001`):

```powershell
npm start
```

2. (Opcional) Usar otro puerto temporalmente en PowerShell:

```powershell
$env:PORT=3002; npm start
```

3. Abre tu navegador y visita `http://localhost:3001` (o el puerto que hayas elegido).

Credenciales demo
- Email: `demo@example.com`
- Contraseña: `demo123`

Notas importantes
- La API guarda los datos en `./database/tareas.db` automáticamente la primera vez que arranca.
- Para mantener lógica segura y privada, evita poner secretos o validaciones sensibles únicamente en `public/script.js`; toda lógica sensible debe ejecutarse en el servidor (`server.js`).
- El acceso directo a `http://localhost:3001/script.js` está protegido por el servidor: el archivo sigue funcionando normalmente cuando se carga la aplicación, pero devolverá 404 si se intenta abrir su URL directamente sin venir desde nuestras páginas o sin sesión.

Si quieres, puedo añadir instrucciones para ejecutar pruebas automáticas o un script de desarrollo con `nodemon`.

