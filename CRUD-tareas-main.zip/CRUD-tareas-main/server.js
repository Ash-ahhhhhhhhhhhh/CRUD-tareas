const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;

// Crear carpeta database si no existe
if (!fs.existsSync('./database')) {
    fs.mkdirSync('./database');
    console.log('📁 Carpeta database creada');
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'mi_secreto_2026',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 horas
}));

// Servir archivos estáticos PRIMERO (para evitar bloqueos)
app.use(express.static('public'));

// Middleware de protección HTML (solo redirigir, no bloquear)
app.use((req, res, next) => {
    // Solo para páginas HTML específicas
    if (req.path === '/index.html') {
        if (!req.session || !req.session.usuarioId) {
            return res.redirect('/login.html');
        }
    }
    next();
});

// Conectar a la base de datos
const db = new sqlite3.Database('./database/tareas.db', (err) => {
    if (err) {
        console.error('❌ Error conectando a DB:', err.message);
    } else {
        console.log('✅ Conectado a SQLite');
    }
});

// Crear tablas y asegurar columnas
db.serialize(() => {
    // Tabla de usuarios
    db.run(`CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        nombre TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    
    // Tabla de tareas
    db.run(`CREATE TABLE IF NOT EXISTS tareas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        titulo TEXT NOT NULL,
        descripcion TEXT,
        prioridad TEXT DEFAULT 'media',
        vencimiento TEXT,
        completada INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    )`);
    
    console.log('✅ Tablas creadas/verificadas');

    // Agregar columnas de preferencias si no existen (CORREGIDO)
    db.all("PRAGMA table_info(usuarios)", (err, cols) => {
        if (err) {
            console.error('Error obteniendo info de tabla:', err);
            return;
        }
        
        const columnNames = cols.map(c => c.name);
        
        if (!columnNames.includes('theme_bg')) {
            db.run("ALTER TABLE usuarios ADD COLUMN theme_bg TEXT DEFAULT 'white'", (err) => {
                if (err) console.error('Error agregando theme_bg:', err.message);
                else console.log('✅ Columna theme_bg agregada');
            });
        }
        
        if (!columnNames.includes('table_color')) {
            db.run("ALTER TABLE usuarios ADD COLUMN table_color TEXT DEFAULT '#667eea'", (err) => {
                if (err) console.error('Error agregando table_color:', err.message);
                else console.log('✅ Columna table_color agregada');
            });
        }
        
        if (!columnNames.includes('rainbow')) {
            db.run("ALTER TABLE usuarios ADD COLUMN rainbow INTEGER DEFAULT 0", (err) => {
                if (err) console.error('Error agregando rainbow:', err.message);
                else console.log('✅ Columna rainbow agregada');
            });
        }
    });

    // Crear usuario demo (CORREGIDO - más robusto)
    db.get("SELECT id FROM usuarios WHERE email = ?", ['demo@example.com'], async (err, row) => {
        if (err) {
            console.error('Error verificando usuario demo:', err);
            return;
        }
        
        if (!row) {
            const hashedPassword = await bcrypt.hash('demo123', 10);
            db.run(
                "INSERT INTO usuarios (email, password, nombre) VALUES (?, ?, ?)",
                ['demo@example.com', hashedPassword, 'Usuario Demo'],
                function(err) {
                    if (err) {
                        console.error('Error creando usuario demo:', err);
                    } else {
                        console.log('✅ Usuario demo creado: demo@example.com / demo123');
                    }
                }
            );
        } else {
            console.log('ℹ️ Usuario demo ya existe');
        }
    });
});

// Ruta de registro (CORREGIDO - manejo de columnas)
app.post('/api/register', async (req, res) => {
    console.log('📝 Intentando registrar:', req.body.email);
    const { nombre, email, password } = req.body;
    
    if (!nombre || !email || !password) {
        return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }
    
    if (password.length < 4) {
        return res.status(400).json({ error: 'La contraseña debe tener al menos 4 caracteres' });
    }
    
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Insertar solo los campos base
        db.run("INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)",
            [nombre, email, hashedPassword],
            function(err) {
                if (err) {
                    console.error('Error DB:', err.message);
                    if (err.message.includes('UNIQUE')) {
                        return res.status(400).json({ error: 'El email ya está registrado' });
                    }
                    return res.status(500).json({ error: 'Error en el servidor' });
                }

                req.session.usuarioId = this.lastID;
                req.session.usuarioNombre = nombre;

                console.log('✅ Usuario registrado:', email);
                res.json({ 
                    success: true, 
                    usuario: { id: this.lastID, nombre, email },
                    preferences: { theme_bg: 'white', table_color: '#667eea', rainbow: false }
                });
            });
    } catch (error) {
        console.error('Error en registro:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

// Ruta de login (CORREGIDO)
app.post('/api/login', async (req, res) => {
    console.log('🔐 Intento de login:', req.body.email);
    const { email, password } = req.body;
    
    db.get("SELECT * FROM usuarios WHERE email = ?", [email], async (err, usuario) => {
        if (err || !usuario) {
            return res.status(401).json({ error: 'Credenciales incorrectas' });
        }
        
        const valido = await bcrypt.compare(password, usuario.password);
        if (!valido) {
            return res.status(401).json({ error: 'Credenciales incorrectas' });
        }
        
        req.session.usuarioId = usuario.id;
        req.session.usuarioNombre = usuario.nombre;

        // Obtener preferencias con valores por defecto
        const prefs = { 
            theme_bg: usuario.theme_bg || 'white', 
            table_color: usuario.table_color || '#667eea', 
            rainbow: usuario.rainbow === 1 
        };
        
        console.log('✅ Login exitoso:', email);
        res.json({ 
            success: true, 
            usuario: { id: usuario.id, nombre: usuario.nombre, email: usuario.email }, 
            preferences: prefs 
        });
    });
});

// Verificar sesión
app.get('/api/verificar-sesion', (req, res) => {
    if (req.session && req.session.usuarioId) {
        db.get("SELECT nombre, theme_bg, table_color, rainbow FROM usuarios WHERE id = ?", 
            [req.session.usuarioId], 
            (err, row) => {
                if (err || !row) {
                    return res.json({ autenticado: true, usuario: { nombre: req.session.usuarioNombre } });
                }
                res.json({ 
                    autenticado: true, 
                    usuario: { nombre: row.nombre },
                    preferences: { 
                        theme_bg: row.theme_bg || 'white', 
                        table_color: row.table_color || '#667eea', 
                        rainbow: row.rainbow === 1 
                    }
                });
            });
    } else {
        res.json({ autenticado: false });
    }
});

// Obtener preferencias
app.get('/api/preferences', verificarAuth, (req, res) => {
    db.get("SELECT theme_bg, table_color, rainbow FROM usuarios WHERE id = ?", 
        [req.session.usuarioId], 
        (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ 
                theme_bg: row?.theme_bg || 'white', 
                table_color: row?.table_color || '#667eea', 
                rainbow: row?.rainbow === 1 
            });
        });
});

// Actualizar preferencias
app.post('/api/preferences', verificarAuth, (req, res) => {
    const { theme_bg, table_color, rainbow } = req.body;
    db.run("UPDATE usuarios SET theme_bg = ?, table_color = ?, rainbow = ? WHERE id = ?",
        [theme_bg || 'white', table_color || '#667eea', rainbow ? 1 : 0, req.session.usuarioId], 
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true });
        });
});

// Logout
app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error('Error destroying session:', err);
        res.json({ success: true });
    });
});

// Middleware de autenticación
function verificarAuth(req, res, next) {
    if (!req.session || !req.session.usuarioId) {
        return res.status(401).json({ error: 'No autorizado' });
    }
    next();
}

// CRUD de tareas (igual, funcionan bien)
app.get('/api/tareas', verificarAuth, (req, res) => {
    db.all("SELECT * FROM tareas WHERE usuario_id = ? ORDER BY created_at DESC",
        [req.session.usuarioId],
        (err, tareas) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(tareas.map(t => ({ ...t, completada: t.completada === 1 })));
        });
});

app.post('/api/tareas', verificarAuth, (req, res) => {
    const { titulo, descripcion, prioridad, vencimiento } = req.body;

    if (!titulo) return res.status(400).json({ error: 'El título es requerido' });

    db.run("INSERT INTO tareas (usuario_id, titulo, descripcion, prioridad, vencimiento) VALUES (?, ?, ?, ?, ?)",
        [req.session.usuarioId, titulo, descripcion, prioridad || 'media', vencimiento || null],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ id: this.lastID, titulo, descripcion, prioridad: prioridad || 'media', vencimiento: vencimiento || null, completada: false });
        });
});

app.put('/api/tareas/:id', verificarAuth, (req, res) => {
    const { completada, titulo, descripcion, prioridad, vencimiento } = req.body;

    if (typeof completada !== 'undefined') {
        db.run("UPDATE tareas SET completada = ? WHERE id = ? AND usuario_id = ?",
            [completada ? 1 : 0, req.params.id, req.session.usuarioId],
            function(err) {
                if (err) return res.status(500).json({ error: err.message });
                res.json({ success: true });
            });
        return;
    }

    db.run("UPDATE tareas SET titulo = ?, descripcion = ?, prioridad = ?, vencimiento = ? WHERE id = ? AND usuario_id = ?",
        [titulo, descripcion, prioridad || 'media', vencimiento || null, req.params.id, req.session.usuarioId],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true });
        });
});

app.delete('/api/tareas/:id', verificarAuth, (req, res) => {
    db.run("DELETE FROM tareas WHERE id = ? AND usuario_id = ?",
        [req.params.id, req.session.usuarioId],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true });
        });
});

// Servir archivos HTML
app.get('/', (req, res) => {
    if (req.session && req.session.usuarioId) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    } else {
        res.sendFile(path.join(__dirname, 'public', 'login.html'));
    }
});

app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/index.html', (req, res) => {
    if (req.session && req.session.usuarioId) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    } else {
        res.redirect('/login.html');
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`\n🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📝 Usuario demo: demo@example.com / demo123`);
    console.log(`💡 Abre tu navegador y ve a: http://localhost:${PORT}\n`);
});