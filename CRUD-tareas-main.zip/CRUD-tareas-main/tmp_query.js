const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database/tareas.db');
const email = 'prueba+nuevo@example.com';
 db.get("SELECT id,nombre,email,theme_bg,table_color,rainbow FROM usuarios WHERE email = ?", [email], (err, row) => {
  if (err) { console.error('ERROR', err); process.exit(1); }
  console.log(JSON.stringify(row, null, 2));
  db.close();
});
