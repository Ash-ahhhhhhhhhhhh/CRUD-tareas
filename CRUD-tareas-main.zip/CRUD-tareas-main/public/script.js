let tareasActuales = [];
let filtroActual = 'todas';
let colorPalette = [];
let globalRainbow = false;

// Verificar sesión al cargar
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/verificar-sesion');
        const data = await response.json();
        
        if (data.autenticado) {
            // Si está autenticado y está en login.html o root, redirigir a index
            if (window.location.pathname.includes('login.html') || window.location.pathname === '/') {
                if (data.preferences) applyPreferences(data.preferences);
                window.location.href = '/index.html';
            } else {
                document.getElementById('userName').textContent = `👤 ${data.usuario.nombre}`;
                if (data.preferences) applyPreferences(data.preferences);
                await cargarTareas();
                initSettings();
            }
        } else {
            // Si no está autenticado y no está en login.html, redirigir
            if (!window.location.pathname.includes('login.html')) {
                window.location.href = '/login.html';
            }
        }
    } catch (error) {
        console.error('Error al verificar sesión:', error);
    }
});

// Funciones de autenticación
async function login(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
                if (data.preferences) applyPreferences(data.preferences);
                window.location.href = '/index.html';
        } else {
            mostrarError(data.error);
        }
    } catch (error) {
        mostrarError('Error al conectar con el servidor');
    }
}

async function register(event) {
    event.preventDefault();
    const nombre = document.getElementById('regNombre').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
                if (data.preferences) applyPreferences(data.preferences);
                window.location.href = '/index.html';
        } else {
            mostrarError(data.error);
        }
    } catch (error) {
        mostrarError('Error al conectar con el servidor');
    }
}

function mostrarError(mensaje) {
    const loginError = document.getElementById('errorMsg');
    if (loginError) {
        loginError.textContent = mensaje;
        loginError.style.display = 'block';
        setTimeout(() => loginError.style.display = 'none', 3000);
        return;
    }
    showAppMsg(mensaje, 3000);
}

function showAppMsg(text, duration = 2500) {
    const el = document.getElementById('appMsg');
    if (!el) return;
    el.textContent = text;
    el.style.display = 'block';
    setTimeout(() => el.style.display = 'none', duration);
}

function mostrarFormulario(tipo) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const tabs = document.querySelectorAll('.tab-btn');
    
    if (tipo === 'login') {
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
        tabs[0].classList.add('active');
        tabs[1].classList.remove('active');
    } else {
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
        tabs[0].classList.remove('active');
        tabs[1].classList.add('active');
    }
}

async function cerrarSesion() {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login.html';
}

// Funciones CRUD de tareas
async function cargarTareas() {
    try {
        const response = await fetch('/api/tareas');
        const tareas = await response.json();
        tareasActuales = tareas;
        mostrarTareas();
    } catch (error) {
        console.error('Error al cargar tareas:', error);
    }
}

function mostrarTareas() {
    const container = document.getElementById('tareasContainer');
    let tareasFiltradas = tareasActuales;
    
    if (filtroActual === 'pendientes') {
        tareasFiltradas = tareasActuales.filter(t => !t.completada);
    } else if (filtroActual === 'completadas') {
        tareasFiltradas = tareasActuales.filter(t => t.completada);
    }
    
    if (tareasFiltradas.length === 0) {
        container.innerHTML = '<div class="loading">No hay tareas para mostrar</div>';
        return;
    }

    container.innerHTML = `
        <table class="tareas-table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Prioridad</th>
                    <th>Descripción</th>
                    <th>Vence</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                ${tareasFiltradas.map(tarea => `
                    <tr class="${tarea.completada ? 'completada' : ''} ${globalRainbow ? 'rainbow' : ''}" data-id="${tarea.id}">
                        <td>
                            <div class="cell-title">
                                <span>${escapeHtml(tarea.titulo)}</span>
                                ${tarea.completada ? '<span class="status-label">Completada</span>' : ''}
                            </div>
                        </td>
                        <td><span class="prioridad prioridad-${tarea.prioridad || 'media'}">${tarea.prioridad || 'media'}</span></td>
                        <td>${tarea.descripcion ? escapeHtml(tarea.descripcion) : '-'}</td>
                        <td>${tarea.vencimiento ? new Date(tarea.vencimiento).toLocaleString() : '-'}</td>
                        <td class="actions-cell">
                            <button class="btn-toggle" data-id="${tarea.id}">${tarea.completada ? '✓ Reabrir' : '○ Completar'}</button>
                            <button class="btn-edit" data-id="${tarea.id}">✎ Editar</button>
                            <button class="btn-delete" data-id="${tarea.id}">🗑 Eliminar</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;

    // Delegación de eventos para botones generados dinámicamente
    container.querySelectorAll('.btn-toggle').forEach(b => b.addEventListener('click', (e) => toggleCompletada(Number(e.currentTarget.dataset.id))));
    container.querySelectorAll('.btn-edit').forEach(b => b.addEventListener('click', (e) => editarTarea(Number(e.currentTarget.dataset.id))));
    container.querySelectorAll('.btn-delete').forEach(b => b.addEventListener('click', (e) => eliminarTarea(Number(e.currentTarget.dataset.id))));
}

async function guardarTarea(event) {
    event.preventDefault();
    const editId = document.getElementById('editId').value;
    const titulo = document.getElementById('titulo').value;
    const descripcion = document.getElementById('descripcion').value;
    const prioridad = document.getElementById('prioridad').value;
    const vencimiento = document.getElementById('vencimiento').value;
    
    const tareaData = { titulo, descripcion, prioridad, vencimiento };
    
    try {
        let response;
        if (editId) {
            response = await fetch(`/api/tareas/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(tareaData)
            });
        } else {
            response = await fetch('/api/tareas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(tareaData)
            });
        }
        
        if (response.ok) {
            resetFormulario();
            cargarTareas();
        } else {
            const error = await response.json();
            mostrarError(error.error || 'Error al guardar');
        }
    } catch (error) {
        console.error('Error al guardar tarea:', error);
    }
}

async function editarTarea(id) {
    const tarea = tareasActuales.find(t => t.id === id);
    if (tarea) {
        document.getElementById('editId').value = tarea.id;
        document.getElementById('titulo').value = tarea.titulo;
        document.getElementById('descripcion').value = tarea.descripcion || '';
        document.getElementById('prioridad').value = tarea.prioridad || 'media';
        if (tarea.vencimiento) {
            document.getElementById('vencimiento').value = tarea.vencimiento.slice(0, 16);
        }
        document.getElementById('cancelBtn').style.display = 'inline-block';
        document.querySelector('.task-form-container h2').textContent = 'Editar Tarea';
    }
}

async function eliminarTarea(id) {
    const ok = await confirmAction('¿Estás seguro de eliminar esta tarea?');
    if (!ok) return;
    try {
        const response = await fetch(`/api/tareas/${id}`, { method: 'DELETE' });
        if (response.ok) cargarTareas();
    } catch (error) { console.error('Error al eliminar tarea:', error); }
}

async function toggleCompletada(id) {
    const tarea = tareasActuales.find(t => t.id === id);
    try {
        const response = await fetch(`/api/tareas/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completada: !tarea.completada })
        });
        
        if (response.ok) {
            cargarTareas();
        }
    } catch (error) {
        console.error('Error al cambiar estado:', error);
    }
}

function resetFormulario() {
    document.getElementById('editId').value = '';
    document.getElementById('titulo').value = '';
    document.getElementById('descripcion').value = '';
    document.getElementById('prioridad').value = 'media';
    document.getElementById('vencimiento').value = '';
    document.getElementById('cancelBtn').style.display = 'none';
    document.querySelector('.task-form-container h2').textContent = 'Nueva Tarea';
}

function cancelarEdicion() {
    resetFormulario();
}

function filtrarTareas(filtro) {
    filtroActual = filtro;
    mostrarTareas();
    
    // Actualizar botones activos
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-filter') === filtro) {
            btn.classList.add('active');
        }
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Confirm modal helper
function confirmAction(message) {
    return new Promise(resolve => {
        const modal = document.getElementById('confirmModal');
        const text = document.getElementById('confirmText');
        const yes = document.getElementById('confirmYes');
        const no = document.getElementById('confirmNo');
        text.textContent = message;
        modal.style.display = 'flex';

        function cleanup(result) {
            modal.style.display = 'none';
            yes.removeEventListener('click', onYes);
            no.removeEventListener('click', onNo);
            resolve(result);
        }
        function onYes() { cleanup(true); }
        function onNo() { cleanup(false); }

        yes.addEventListener('click', onYes);
        no.addEventListener('click', onNo);
    });
}

// Preferences: load, init and save
async function loadPreferences() {
    try {
        const res = await fetch('/api/preferences');
        if (!res.ok) return null;
        return await res.json();
    } catch (e) { return null; }
}

function initSettings() {
    // load palette from localStorage
    try { colorPalette = JSON.parse(localStorage.getItem('colorPalette') || '[]'); } catch(e){ colorPalette = []; }
    const paletteEl = document.getElementById('colorPalette');
    paletteEl.innerHTML = '';
    colorPalette.forEach(c => addSwatch(c));

    const colorInput = document.getElementById('colorPicker');
    document.getElementById('addColorBtn').addEventListener('click', () => {
        const color = colorInput.value;
        if (!colorPalette.includes(color)) {
            colorPalette.push(color);
            localStorage.setItem('colorPalette', JSON.stringify(colorPalette));
            addSwatch(color);
            setTableColor(color);
            savePreferences();
        }
    });

    colorInput.addEventListener('input', () => {
        setTableColor(colorInput.value);
    });

    document.getElementById('bgWhite').addEventListener('change', () => {
        applyPreferences({ theme_bg: 'white', table_color: colorInput.value, rainbow: document.getElementById('rainbowToggle').checked });
        savePreferences();
    });
    document.getElementById('bgBlack').addEventListener('change', () => {
        applyPreferences({ theme_bg: 'black', table_color: colorInput.value, rainbow: document.getElementById('rainbowToggle').checked });
        savePreferences();
    });
    document.getElementById('rainbowToggle').addEventListener('change', () => {
        applyPreferences({ theme_bg: document.getElementById('bgBlack').checked ? 'black' : 'white', table_color: colorInput.value, rainbow: document.getElementById('rainbowToggle').checked });
        savePreferences();
    });

    // Botón paleta para mostrar/ocultar panel de preferencias
    const paletteBtn = document.getElementById('paletteBtn');
    const settingsModal = document.getElementById('settingsModal');
    const closeBtn = document.getElementById('closeSettings');
    if (paletteBtn && settingsModal) {
        paletteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleSettings();
        });
        closeBtn?.addEventListener('click', () => toggleSettings());
        settingsModal.addEventListener('click', (ev) => {
            if (ev.target === settingsModal) toggleSettings();
        });
    }

    // try load server preferences
    loadPreferences().then(p => {
        if (!p) return;
        if (p.theme_bg === 'black') document.getElementById('bgBlack').checked = true;
        else document.getElementById('bgWhite').checked = true;
        document.getElementById('colorPicker').value = p.table_color || '#667eea';
        setTableColor(p.table_color || '#667eea');
        document.getElementById('rainbowToggle').checked = !!p.rainbow;
        applyPreferences(p);
    });
}

function addSwatch(color) {
    const paletteEl = document.getElementById('colorPalette');
    const sw = document.createElement('div');
    sw.className = 'color-swatch';
    sw.style.background = color;
    sw.title = color;
    sw.addEventListener('click', () => {
        setTableColor(color);
        savePreferences();
    });
    paletteEl.appendChild(sw);
    updateSwatchSelection(color);
}

function setTableColor(color) {
    const root = document.documentElement;
    root.style.setProperty('--accent-color', color);
    root.style.setProperty('--table-bg', hexToRgba(color, 0.14));
    root.style.setProperty('--row-bg', hexToRgba(color, 0.2));
    const colorInput = document.getElementById('colorPicker');
    if (colorInput) colorInput.value = color;
    updateSwatchSelection(color);
}

function hexToRgba(hex, alpha) {
    let cleaned = hex.replace('#', '').trim();
    if (cleaned.length === 3) cleaned = cleaned.split('').map(c => c + c).join('');
    const bigint = parseInt(cleaned, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function updateSwatchSelection(color) {
    document.querySelectorAll('.color-swatch').forEach(el => {
        el.classList.toggle('selected', el.style.backgroundColor === color || el.title.toLowerCase() === color.toLowerCase());
    });
}

async function savePreferences() {
    const theme_bg = document.getElementById('bgBlack').checked ? 'black' : 'white';
    const table_color = document.getElementById('colorPicker').value;
    const rainbow = document.getElementById('rainbowToggle').checked;
    globalRainbow = rainbow;
    setTableColor(table_color);
    // apply rainbow locally
    document.querySelectorAll('.tareas-table tbody tr, .tarea-card').forEach(el => {
        if (globalRainbow) el.classList.add('rainbow'); else el.classList.remove('rainbow');
    });
    try {
        await fetch('/api/preferences', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ theme_bg, table_color, rainbow })
        });
        showAppMsg('Preferencias guardadas', 1500);
    } catch (e) { console.warn('No se pudieron guardar preferencias'); }
}

function applyPreferences(p) {
    if (!p) return;
    globalRainbow = !!p.rainbow;
    if (p.theme_bg === 'black') document.body.style.background = '#111'; else document.body.style.background = '#fff';
    setTableColor(p.table_color || '#667eea');
    document.querySelectorAll('.tareas-table tbody tr, .tarea-card').forEach(el => {
        if (globalRainbow) el.classList.add('rainbow'); else el.classList.remove('rainbow');
    });
}

function toggleSettings() {
    const settingsModal = document.getElementById('settingsModal');
    if (!settingsModal) return;
    const open = settingsModal.classList.toggle('open');
    settingsModal.setAttribute('aria-hidden', (!open).toString());
}